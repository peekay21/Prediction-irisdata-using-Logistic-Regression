### Predict iris data using Logistic Regression

-------------------------------------------------------

#### Logistic Regression is a machine learning algorithm which is used when the dependent variable (target) is categorical.



```python
#Library version

import sys
print('Python version : {} '.format(sys.version))

import numpy as np
print('Numpy version : {} '.format(np.__version__))

import pandas as pd
print('Pandas version: {}'.format(pd.__version__))

import sklearn
print('sklearn: {}'.format(sklearn.__version__))
```

    Python version : 3.7.7 (default, Mar 23 2020, 23:19:08) [MSC v.1916 64 bit (AMD64)] 
    Numpy version : 1.18.1 
    Pandas version: 1.0.3
    sklearn: 0.22.1
    


```python
#libraries
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import plot_confusion_matrix
import matplotlib.pyplot as plt
```


```python
#laod the data
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
names =['sepal-length','sepal-width','petal-length','petal-width','class']

dataset = pd.read_csv(url, names=names)
```


```python
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal-length</th>
      <th>sepal-width</th>
      <th>petal-length</th>
      <th>petal-width</th>
      <th>class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
#shape of dataset
print(dataset.shape)
```

    (150, 5)
    


```python
# Number of sample dataset of each class 
print(dataset.groupby('class').size())
```

    class
    Iris-setosa        50
    Iris-versicolor    50
    Iris-virginica     50
    dtype: int64
    


```python
#Split the dataset into features and output
# X contains feautures of dataset
# Y contains output class

array = dataset.values

X = array[:,:4]
Y = array[:,4]


```


```python
X
```




    array([[5.1, 3.5, 1.4, 0.2],
           [4.9, 3.0, 1.4, 0.2],
           [4.7, 3.2, 1.3, 0.2],
           [4.6, 3.1, 1.5, 0.2],
           [5.0, 3.6, 1.4, 0.2],
           [5.4, 3.9, 1.7, 0.4],
           [4.6, 3.4, 1.4, 0.3],
           [5.0, 3.4, 1.5, 0.2],
           [4.4, 2.9, 1.4, 0.2],
           [4.9, 3.1, 1.5, 0.1],
           [5.4, 3.7, 1.5, 0.2],
           [4.8, 3.4, 1.6, 0.2],
           [4.8, 3.0, 1.4, 0.1],
           [4.3, 3.0, 1.1, 0.1],
           [5.8, 4.0, 1.2, 0.2],
           [5.7, 4.4, 1.5, 0.4],
           [5.4, 3.9, 1.3, 0.4],
           [5.1, 3.5, 1.4, 0.3],
           [5.7, 3.8, 1.7, 0.3],
           [5.1, 3.8, 1.5, 0.3],
           [5.4, 3.4, 1.7, 0.2],
           [5.1, 3.7, 1.5, 0.4],
           [4.6, 3.6, 1.0, 0.2],
           [5.1, 3.3, 1.7, 0.5],
           [4.8, 3.4, 1.9, 0.2],
           [5.0, 3.0, 1.6, 0.2],
           [5.0, 3.4, 1.6, 0.4],
           [5.2, 3.5, 1.5, 0.2],
           [5.2, 3.4, 1.4, 0.2],
           [4.7, 3.2, 1.6, 0.2],
           [4.8, 3.1, 1.6, 0.2],
           [5.4, 3.4, 1.5, 0.4],
           [5.2, 4.1, 1.5, 0.1],
           [5.5, 4.2, 1.4, 0.2],
           [4.9, 3.1, 1.5, 0.1],
           [5.0, 3.2, 1.2, 0.2],
           [5.5, 3.5, 1.3, 0.2],
           [4.9, 3.1, 1.5, 0.1],
           [4.4, 3.0, 1.3, 0.2],
           [5.1, 3.4, 1.5, 0.2],
           [5.0, 3.5, 1.3, 0.3],
           [4.5, 2.3, 1.3, 0.3],
           [4.4, 3.2, 1.3, 0.2],
           [5.0, 3.5, 1.6, 0.6],
           [5.1, 3.8, 1.9, 0.4],
           [4.8, 3.0, 1.4, 0.3],
           [5.1, 3.8, 1.6, 0.2],
           [4.6, 3.2, 1.4, 0.2],
           [5.3, 3.7, 1.5, 0.2],
           [5.0, 3.3, 1.4, 0.2],
           [7.0, 3.2, 4.7, 1.4],
           [6.4, 3.2, 4.5, 1.5],
           [6.9, 3.1, 4.9, 1.5],
           [5.5, 2.3, 4.0, 1.3],
           [6.5, 2.8, 4.6, 1.5],
           [5.7, 2.8, 4.5, 1.3],
           [6.3, 3.3, 4.7, 1.6],
           [4.9, 2.4, 3.3, 1.0],
           [6.6, 2.9, 4.6, 1.3],
           [5.2, 2.7, 3.9, 1.4],
           [5.0, 2.0, 3.5, 1.0],
           [5.9, 3.0, 4.2, 1.5],
           [6.0, 2.2, 4.0, 1.0],
           [6.1, 2.9, 4.7, 1.4],
           [5.6, 2.9, 3.6, 1.3],
           [6.7, 3.1, 4.4, 1.4],
           [5.6, 3.0, 4.5, 1.5],
           [5.8, 2.7, 4.1, 1.0],
           [6.2, 2.2, 4.5, 1.5],
           [5.6, 2.5, 3.9, 1.1],
           [5.9, 3.2, 4.8, 1.8],
           [6.1, 2.8, 4.0, 1.3],
           [6.3, 2.5, 4.9, 1.5],
           [6.1, 2.8, 4.7, 1.2],
           [6.4, 2.9, 4.3, 1.3],
           [6.6, 3.0, 4.4, 1.4],
           [6.8, 2.8, 4.8, 1.4],
           [6.7, 3.0, 5.0, 1.7],
           [6.0, 2.9, 4.5, 1.5],
           [5.7, 2.6, 3.5, 1.0],
           [5.5, 2.4, 3.8, 1.1],
           [5.5, 2.4, 3.7, 1.0],
           [5.8, 2.7, 3.9, 1.2],
           [6.0, 2.7, 5.1, 1.6],
           [5.4, 3.0, 4.5, 1.5],
           [6.0, 3.4, 4.5, 1.6],
           [6.7, 3.1, 4.7, 1.5],
           [6.3, 2.3, 4.4, 1.3],
           [5.6, 3.0, 4.1, 1.3],
           [5.5, 2.5, 4.0, 1.3],
           [5.5, 2.6, 4.4, 1.2],
           [6.1, 3.0, 4.6, 1.4],
           [5.8, 2.6, 4.0, 1.2],
           [5.0, 2.3, 3.3, 1.0],
           [5.6, 2.7, 4.2, 1.3],
           [5.7, 3.0, 4.2, 1.2],
           [5.7, 2.9, 4.2, 1.3],
           [6.2, 2.9, 4.3, 1.3],
           [5.1, 2.5, 3.0, 1.1],
           [5.7, 2.8, 4.1, 1.3],
           [6.3, 3.3, 6.0, 2.5],
           [5.8, 2.7, 5.1, 1.9],
           [7.1, 3.0, 5.9, 2.1],
           [6.3, 2.9, 5.6, 1.8],
           [6.5, 3.0, 5.8, 2.2],
           [7.6, 3.0, 6.6, 2.1],
           [4.9, 2.5, 4.5, 1.7],
           [7.3, 2.9, 6.3, 1.8],
           [6.7, 2.5, 5.8, 1.8],
           [7.2, 3.6, 6.1, 2.5],
           [6.5, 3.2, 5.1, 2.0],
           [6.4, 2.7, 5.3, 1.9],
           [6.8, 3.0, 5.5, 2.1],
           [5.7, 2.5, 5.0, 2.0],
           [5.8, 2.8, 5.1, 2.4],
           [6.4, 3.2, 5.3, 2.3],
           [6.5, 3.0, 5.5, 1.8],
           [7.7, 3.8, 6.7, 2.2],
           [7.7, 2.6, 6.9, 2.3],
           [6.0, 2.2, 5.0, 1.5],
           [6.9, 3.2, 5.7, 2.3],
           [5.6, 2.8, 4.9, 2.0],
           [7.7, 2.8, 6.7, 2.0],
           [6.3, 2.7, 4.9, 1.8],
           [6.7, 3.3, 5.7, 2.1],
           [7.2, 3.2, 6.0, 1.8],
           [6.2, 2.8, 4.8, 1.8],
           [6.1, 3.0, 4.9, 1.8],
           [6.4, 2.8, 5.6, 2.1],
           [7.2, 3.0, 5.8, 1.6],
           [7.4, 2.8, 6.1, 1.9],
           [7.9, 3.8, 6.4, 2.0],
           [6.4, 2.8, 5.6, 2.2],
           [6.3, 2.8, 5.1, 1.5],
           [6.1, 2.6, 5.6, 1.4],
           [7.7, 3.0, 6.1, 2.3],
           [6.3, 3.4, 5.6, 2.4],
           [6.4, 3.1, 5.5, 1.8],
           [6.0, 3.0, 4.8, 1.8],
           [6.9, 3.1, 5.4, 2.1],
           [6.7, 3.1, 5.6, 2.4],
           [6.9, 3.1, 5.1, 2.3],
           [5.8, 2.7, 5.1, 1.9],
           [6.8, 3.2, 5.9, 2.3],
           [6.7, 3.3, 5.7, 2.5],
           [6.7, 3.0, 5.2, 2.3],
           [6.3, 2.5, 5.0, 1.9],
           [6.5, 3.0, 5.2, 2.0],
           [6.2, 3.4, 5.4, 2.3],
           [5.9, 3.0, 5.1, 1.8]], dtype=object)




```python
#split dataset into train dataset and test dataset

seed = 0.8
validation_size = 6
x_train,x_test,y_train,y_test = train_test_split(X,Y, train_size = seed, random_state=validation_size, shuffle = True)
```


```python
#train the clf classifier 
clf = LogisticRegression().fit(x_train,y_train)
```


```python
#predict the output using x_test dataset
y_pred = clf.predict(x_test)
```


```python
'''
Confusion matrix : Confusion matrix is N X N matrix is used to evaluate the performances of 
the machine learning model. This matrix compares with actual output values with machine learning 
predict's output values.
                            Predicted value
                    positive       |   negative
                 |-----------------|---------------|
        positive |   tp            |    fn         |
                 |                 |               |
actual value     |-----------------|---------------|
                 |  fp             |     tn        |
        negative |                 |               |
                 |-----------------|---------------|

        where, 
                tp - true positive
                fn - false negative
                fp - false positive
                tn - true negative
                
        accuracy : accuracy is the ratio of (tp + tn)/ (tp + fn + fp + tn). The accuracy is 
        intuitively that how correctly our predict the actual output.
        
        Precision: Precision is the ration of ( tp / (tp + fp)) . The precision is intuitively the 
        ability not to label as a sample that is negative.
        
        Recall : The recall is the ratio of tp / tp+ fn . The recall is intuitively the ability of the
        classifier to find all the positive samples.
        

'''

plot_confusion_matrix(clf,x_test,y_test)
plt.show()
print('Accuracy: '+ str(accuracy_score(y_test,y_pred)*100)+' %')
print('Precision: '+ str(precision_score(y_test,y_pred, average ='micro')*100) + ' %' )
print('Recall: ' + str(recall_score(y_test,y_pred, average = 'micro')*100) + ' %')
```


![png](output_12_0.png)


    Accuracy: 96.66666666666667 %
    Precision: 96.66666666666667 %
    Recall: 96.66666666666667 %
    


```python

```
